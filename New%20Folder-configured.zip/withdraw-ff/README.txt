MAGIA TELEGRAM MINI APP — SETUP & DEPLOYMENT

Project contents:
- Telegram Mini App frontend (index.html, withdraw.html, payout.html)
- Node.js HTTP backend (server.js)
- Firestore storage for user profiles, balances and withdrawal requests
- Admin API protected by Telegram initData and ADMIN_TELEGRAM_ID

LOCAL PREVIEW (SPCK)
Open index.html in SPCK. This is a local demo only: browser localStorage is not shared between users/devices, and the demo admin PIN is not secure. Do not use local mode for real funds.

PRODUCTION REQUIREMENTS
1. Create a Firebase project and Firestore database. Create a service account and keep its JSON private.
2. Fill firebase-config.js with your Firebase Web App configuration.
3. Set server environment variables:
   BOT_TOKEN=<BotFather token>
   ADMIN_TELEGRAM_ID=<your numeric Telegram user ID>
   FIREBASE_SERVICE_ACCOUNT_JSON=<service-account JSON as one-line JSON>
   INITIAL_BALANCE=0
   PORT=3000
4. Install Node.js dependencies with `npm install`, then start using `npm start`.
5. Deploy the Node server and frontend together to a public HTTPS domain. Set the domain in BotFather -> your bot -> Bot Settings -> Menu Button / Mini App (menu wording can vary).
6. Open the app from the Telegram bot, not by opening the site directly. Telegram WebApp initData is required for server authentication.
7. Test with a non-admin Telegram account: account creation, insufficient balance, valid/invalid TON and BEP20 addresses, withdrawal creation, history refresh, admin balance adjustment, paid and rejected/refund flows.

SECURITY / OPERATIONS
- Never put BOT_TOKEN or Firebase service-account credentials in client files or commit them to a public repository.
- The Firebase web config is public, but configure Firestore access rules to deny direct client writes; this project uses the Admin SDK on the server.
- Use a strong hosting secret store for environment variables, HTTPS, backups, and monitoring.
- Admin access is based on the Telegram numeric ID verified from signed initData. Replace the placeholder admin ID in script.js too if you want the admin shortcut button to appear.
- Withdrawals are requests only; no blockchain transfer is performed automatically. An operator must verify and send the payout, then mark it Paid. Ensure fee, conversion rates, eligibility and payment operations are configured before launch.
- Payout addresses are currently saved in that user's browser localStorage. They do not roam across devices and are not stored in Firestore. For production, implement server-side address storage and a server-enforced 24-hour address-change lock before accepting real withdrawals.
- Initial balance defaults to 1000 in the code; set INITIAL_BALANCE=0 for production unless you intentionally grant a documented signup balance.
- Referral count is currently a field only; referral attribution/incrementing is not implemented.
- The UI displays a fixed 10,000-point withdrawal amount and currently sets fee to 0. Align these values with your actual business rules before launch.

API addition:
- GET /api/user/withdrawals returns the signed-in user's withdrawal history, so server-backed requests can appear after reopening the app.

This package is prepared as a deployable starter, not a live payment service. It still requires your own Firebase project, bot token, admin ID, HTTPS hosting, and production payment/address-lock implementation.

ADMIN PANEL UPDATE
- admin.html now uses Telegram WebApp initData and the protected /api/admin endpoints; the insecure hardcoded PIN/localStorage admin flow has been removed.
- Admin list, user detail/history, balance credits, pending queue and paid/reject actions are server-backed in Firestore.
- Open admin.html only from Telegram Mini App after setting ADMIN_TELEGRAM_ID and BOT_TOKEN on the server. Direct browser/SPCK admin access is intentionally blocked.
- Mark Paid only after manually completing the actual payout; the app does not transfer crypto automatically.
