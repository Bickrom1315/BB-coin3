
require('dotenv').config({path:path.join(__dirname,'.env')});
const http=require('http'), fs=require('fs'), path=require('path'), crypto=require('crypto');
const admin=require('firebase-admin');
const PORT=Number(process.env.PORT||3000);
const BOT_TOKEN=String(process.env.BOT_TOKEN||'');
const ADMIN_IDS=new Set(String(process.env.ADMIN_TELEGRAM_IDS||process.env.ADMIN_TELEGRAM_ID||'').split(',').map(s=>s.trim()).filter(Boolean));
const APP_URL=String(process.env.APP_URL||'').replace(/\/$/,'');
const INITIAL_SIGNUP_BONUS=Number(process.env.INITIAL_SIGNUP_BONUS||100000);
const RATE=new Map();

function initFirebase(){
  if(admin.apps.length)return;
  if(process.env.FIREBASE_SERVICE_ACCOUNT_JSON){
    admin.initializeApp({credential:admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON))});
  }else if(process.env.GOOGLE_APPLICATION_CREDENTIALS){
    admin.initializeApp({credential:admin.credential.applicationDefault()});
  }else{
    const localCred=path.join(__dirname,'.private','firebase-service-account.json');
    if(fs.existsSync(localCred)){
      admin.initializeApp({credential:admin.credential.cert(require(localCred))});
    }else throw new Error('Firebase credentials are not configured');
  }
}
function db(){initFirebase();return admin.firestore();}
function now(){return admin.firestore.FieldValue.serverTimestamp();}
function send(res,code,obj){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type,X-Telegram-Init-Data,X-Idempotency-Key'});res.end(JSON.stringify(obj));}
function readBody(req){return new Promise((resolve,reject)=>{let b='';req.on('data',c=>{b+=c;if(b.length>1024*1024){reject(new Error('BODY_TOO_LARGE'));req.destroy();}});req.on('end',()=>{try{resolve(b?JSON.parse(b):{})}catch(e){reject(new Error('INVALID_JSON'))}});req.on('error',reject)})}
function safeEqual(a,b){const aa=Buffer.from(a),bb=Buffer.from(b);return aa.length===bb.length&&crypto.timingSafeEqual(aa,bb)}
function verifyInitData(raw){
  if(!BOT_TOKEN||!raw)return null;
  try{
    const p=new URLSearchParams(raw),hash=p.get('hash');if(!hash)return null;p.delete('hash');
    const data=[...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');
    const secret=crypto.createHmac('sha256','WebAppData').update(BOT_TOKEN).digest();
    const expected=crypto.createHmac('sha256',secret).update(data).digest('hex');
    if(!safeEqual(expected,hash))return null;
    const age=Math.floor(Date.now()/1000)-Number(p.get('auth_date')||0);
    if(age<0||age>86400)return null;
    const user=JSON.parse(p.get('user')||'{}');if(!user.id)return null;
    return {id:String(user.id),user,startParam:p.get('start_param')||''};
  }catch{return null}
}
async function auth(req,adminOnly=false){
  const t=verifyInitData(String(req.headers['x-telegram-init-data']||''));
  if(!t)return {error:'Invalid or expired Telegram session'};
  if(adminOnly&&!ADMIN_IDS.has(t.id))return {error:'Admin only'};
  if(!adminOnly&&!await userAllowed(t.id))return {error:'Account is blocked'};
  return t;
}
async function userAllowed(id){const s=await userRef(id).get();return !s.exists||String(s.data().status||'active')!=='blocked'}
function userRef(id){return db().collection('users').doc(String(id))}
function settingsRef(){return db().collection('settings').doc('global')}
function clean(v){
  if(v===null||v===undefined)return v;
  if(v&&typeof v.toDate==='function')return v.toDate().toISOString();
  if(Array.isArray(v))return v.map(clean);
  if(typeof v==='object'){const o={};for(const k of Object.keys(v))o[k]=clean(v[k]);return o}
  return v;
}
function cleanDoc(s){return {id:s.id,...clean(s.data()||{})}}
async function getSettings(){
  const s=await settingsRef().get();
  if(s.exists)return s.data();
  const base={coinName:'BB Coin',signupBonusEnabled:true,signupBonus:INITIAL_SIGNUP_BONUS,minWithdraw:10000,maxWithdraw:1000000000,withdrawFeeType:'fixed',withdrawFee:0,referralEnabled:true,referralBonus:0,withdrawalsEnabled:true,registrationEnabled:true,maintenanceMode:false,depositInstructions:'Contact support for deposit instructions.',paymentMethods:['USDT BEP20','TON'],updatedAt:now(),updatedBy:'system'};
  await settingsRef().set(base,{merge:true});return base;
}
async function logAdmin(adminId,action,targetUserId,previousValue,newValue,reason,result='success'){
  await db().collection('adminLogs').add({adminId:String(adminId),actionType:action,targetUserId:String(targetUserId||''),previousValue:clean(previousValue||null),newValue:clean(newValue||null),reason:String(reason||''),result,timestamp:now(),createdAt:now()});
}
async function addTx(txn,tx){
  const ref=db().collection('transactions').doc(txn.id||('TX'+Date.now()+crypto.randomBytes(5).toString('hex')));
  tx.set(ref,{...txn,id:ref.id,createdAt:now()},{merge:false});return ref.id;
}
function idempotency(req){return String(req.headers['x-idempotency-key']||'').trim().slice(0,128)}
function validInteger(n){return Number.isSafeInteger(n)&&n>0}
function feeFor(amount,s){return s.withdrawFeeType==='percent'?Math.floor(amount*Number(s.withdrawFee||0)/100):Number(s.withdrawFee||0)}

async function ensureUser(t){
  const ref=userRef(t.id),s=await ref.get();
  if(s.exists){
    await ref.set({firstName:t.user.first_name||'',lastName:t.user.last_name||'',username:t.user.username||'',photoUrl:t.user.photo_url||'',lastActiveAt:now(),updatedAt:now()},{merge:true});
    return {...cleanDoc(await ref.get()),isNew:false};
  }
  const settings=await getSettings();
  if(settings.registrationEnabled===false)throw new Error('REGISTRATION_DISABLED');
  const bonus=settings.signupBonusEnabled?Number(settings.signupBonus||0):0;
  const referralId=String(t.startParam||'').match(/^\d+$/)?String(t.startParam):'';
  const d=db(), txId='TX'+Date.now()+crypto.randomBytes(5).toString('hex');
  await d.runTransaction(async tx=>{
    const again=await tx.get(ref);if(again.exists)return;
    let referrerRef=null, referrerSnap=null;
    if(referralId&&referralId!==t.id){referrerRef=userRef(referralId);referrerSnap=await tx.get(referrerRef)}
    const data={telegramId:t.id,firstName:t.user.first_name||'',lastName:t.user.last_name||'',username:t.user.username||'',photoUrl:t.user.photo_url||'',balance:bonus,status:'active',signupBonus:bonus,signupBonusReceived:bonus>0,referralCount:0,referralEarnings:0,totalDeposits:0,totalWithdrawals:0,pendingWithdrawals:0,createdAt:now(),lastActiveAt:now(),updatedAt:now()};
    tx.set(ref,data);
    if(bonus>0)tx.set(d.collection('transactions').doc(txId),{id:txId,telegramId:t.id,type:'signup_bonus',amount:bonus,balanceAfter:bonus,createdAt:now(),note:'Signup bonus'});
    if(referrerSnap&&referrerSnap.exists&&String(referrerSnap.data().status||'active')!=='blocked'&&Number(settings.referralBonus||0)>0&&settings.referralEnabled!==false){
      const r=referrerSnap.data(),reward=Number(settings.referralBonus||0),rid='REF'+Date.now()+crypto.randomBytes(4).toString('hex');
      tx.update(referrerRef,{balance:Number(r.balance||0)+reward,referralCount:admin.firestore.FieldValue.increment(1),referralEarnings:admin.firestore.FieldValue.increment(reward),updatedAt:now()});
      tx.set(d.collection('referrals').doc(rid),{id:rid,referrerUserId:referralId,referredUserId:t.id,rewardAmount:reward,rewardStatus:'paid',createdAt:now()});
      tx.set(d.collection('transactions').doc('TX'+crypto.randomBytes(8).toString('hex')),{telegramId:referralId,type:'referral_bonus',amount:reward,balanceAfter:Number(r.balance||0)+reward,createdAt:now(),referenceId:rid});
    }
  });
  return {...cleanDoc(await ref.get()),isNew:true};
}

async function rateLimit(req,id){
  const key=id||req.socket.remoteAddress||'unknown',v=RATE.get(key)||{n:0,t:Date.now()};
  if(Date.now()-v.t>60000){v.n=0;v.t=Date.now()} v.n++;RATE.set(key,v);return v.n<=120;
}

async function api(req,res,url){
  if(!(await rateLimit(req,req.headers['x-telegram-init-data']||'')))return send(res,429,{ok:false,error:'Too many requests'});
  if(req.method==='OPTIONS')return send(res,204,{});
  if(url.pathname==='/api/user/sync'&&req.method==='POST'){const t=await auth(req);if(t.error)return send(res,401,{ok:false,error:t.error});return send(res,200,{ok:true,user:await ensureUser(t),settings:clean(await getSettings())})}
  if(url.pathname==='/api/user/me'&&req.method==='GET'){const t=await auth(req);if(t.error)return send(res,401,{ok:false,error:t.error});const u=await ensureUser(t);return send(res,200,{ok:true,user:u,settings:clean(await getSettings())})}
  if(url.pathname==='/api/user/withdrawals'&&req.method==='GET'){const t=await auth(req);if(t.error)return send(res,401,{ok:false,error:t.error});const s=await db().collection('withdrawals').where('telegramId','==',t.id).get();return send(res,200,{ok:true,withdrawals:s.docs.map(cleanDoc).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))})}
  if(url.pathname==='/api/user/transactions'&&req.method==='GET'){const t=await auth(req);if(t.error)return send(res,401,{ok:false,error:t.error});const s=await db().collection('transactions').where('telegramId','==',t.id).get();return send(res,200,{ok:true,transactions:s.docs.map(cleanDoc).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))})}
  if(url.pathname==='/api/user/settings'&&req.method==='GET'){const t=await auth(req);if(t.error)return send(res,401,{ok:false,error:t.error});return send(res,200,{ok:true,settings:clean(await getSettings())})}

  if(url.pathname==='/api/deposit'&&req.method==='POST'){
    const t=await auth(req);if(t.error)return send(res,401,{ok:false,error:t.error});
    const x=await readBody(req),amount=Number(x.amount),method=String(x.method||'').slice(0,40),reference=String(x.reference||'').slice(0,120),key=idempotency(req);
    if(!validInteger(amount))return send(res,400,{ok:false,error:'Amount must be a positive whole number'});
    if(!method||!reference)return send(res,400,{ok:false,error:'Payment method and transaction/reference ID are required'});
    const d=db(),docId=key?('DPKEY_'+crypto.createHash('sha256').update(t.id+key).digest('hex').slice(0,40)):('DP'+Date.now()+crypto.randomBytes(5).toString('hex'));
    const dr=d.collection('deposits').doc(docId),existing=await dr.get();if(existing.exists)return send(res,200,{ok:true,id:docId,status:existing.data().status});
    await dr.set({id:docId,telegramId:t.id,amount,method,reference,status:'pending',createdAt:now(),updatedAt:now()});
    return send(res,201,{ok:true,id:docId,status:'pending'});
  }

  if(url.pathname==='/api/withdraw'&&req.method==='POST'){
    const t=await auth(req);if(t.error)return send(res,401,{ok:false,error:t.error});
    const s=await getSettings(),x=await readBody(req),amount=Number(x.amount),method=String(x.method||''),address=String(x.address||'').trim(),key=idempotency(req);
    if(s.withdrawalsEnabled===false)return send(res,400,{ok:false,error:'Withdrawals are disabled'});
    if(!validInteger(amount)||amount<Number(s.minWithdraw||0)||amount>Number(s.maxWithdraw||0))return send(res,400,{ok:false,error:`Withdrawal must be between ${Number(s.minWithdraw||0).toLocaleString()} and ${Number(s.maxWithdraw||0).toLocaleString()}`});
    if(!['TON','USDT'].includes(method))return send(res,400,{ok:false,error:'Unsupported withdrawal method'});
    if(method==='TON'&&!(/^(EQ|UQ)[A-Za-z0-9_-]{46}$/.test(address)||/^-?\d+:[0-9a-fA-F]{64}$/.test(address)))return send(res,400,{ok:false,error:'Invalid TON address'});
    if(method==='USDT'&&!/^0x[0-9a-fA-F]{40}$/.test(address))return send(res,400,{ok:false,error:'Invalid USDT BEP20 address'});
    const fee=feeFor(amount,s),net=amount-fee;if(net<=0)return send(res,400,{ok:false,error:'Fee exceeds requested amount'});
    const d=db(),keyId=key?('WDKEY_'+crypto.createHash('sha256').update(t.id+key).digest('hex').slice(0,40)):('WD'+Date.now()+crypto.randomBytes(5).toString('hex')),wr=d.collection('withdrawals').doc(keyId);
    const existing=await wr.get();if(existing.exists)return send(res,200,{ok:true,id:keyId,status:existing.data().status});
    await d.runTransaction(async tx=>{
      const ur=userRef(t.id),us=await tx.get(ur);if(!us.exists)throw new Error('USER_NOT_FOUND');
      if(String(us.data().status||'active')==='blocked')throw new Error('BLOCKED');
      const bal=Number(us.data().balance||0);if(bal<amount)throw new Error('INSUFFICIENT_BALANCE');
      tx.update(ur,{balance:bal-amount,pendingWithdrawals:admin.firestore.FieldValue.increment(1),totalWithdrawals:admin.firestore.FieldValue.increment(amount),updatedAt:now()});
      tx.set(wr,{id:keyId,telegramId:t.id,username:us.data().username||'',amount,fee,netAmount:net,method,address,status:'pending',createdAt:now(),updatedAt:now()});
      await addTx({telegramId:t.id,type:'withdraw',amount:-amount,balanceAfter:bal-amount,referenceId:keyId,fee},tx);
    });
    return send(res,201,{ok:true,id:keyId,status:'pending',fee,netAmount:net});
  }

  const am=url.pathname.match(/^\/api\/admin\/users\/([^/]+)$/);
  if(url.pathname==='/api/admin/dashboard'&&req.method==='GET'){
    const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});
    const d=db(),users=await d.collection('users').get(),deps=await d.collection('deposits').get(),wds=await d.collection('withdrawals').get(),txs=await d.collection('transactions').orderBy('createdAt','desc').limit(20).get();
    let active=0,blocked=0,balance=0;users.forEach(x=>{const u=x.data();if(u.status==='blocked')blocked++;else active++;balance+=Number(u.balance||0)});
    const pendingDeposits=deps.docs.filter(x=>x.data().status==='pending').length,pendingWithdrawals=wds.docs.filter(x=>x.data().status==='pending').length;
    return send(res,200,{ok:true,stats:{totalUsers:users.size,activeUsers:active,blockedUsers:blocked,totalBalance:balance,pendingDeposits,pendingWithdrawals,totalDeposits:deps.docs.filter(x=>x.data().status==='paid').reduce((a,x)=>a+Number(x.data().amount||0),0),totalWithdrawals:wds.docs.filter(x=>x.data().status==='paid').reduce((a,x)=>a+Number(x.data().amount||0),0)},recentTransactions:txs.docs.map(cleanDoc),settings:clean(await getSettings())});
  }
  if(url.pathname==='/api/admin/users'&&req.method==='GET'){
    const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});
    const snap=await db().collection('users').orderBy('createdAt','desc').limit(500).get();return send(res,200,{ok:true,count:snap.size,users:snap.docs.map(cleanDoc)});
  }
  if(am&&req.method==='GET'){
    const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const id=decodeURIComponent(am[1]),u=await userRef(id).get();if(!u.exists)return send(res,404,{ok:false,error:'User not found'});
    const [w,tr,refs]=await Promise.all([db().collection('withdrawals').where('telegramId','==',id).get(),db().collection('transactions').where('telegramId','==',id).get(),db().collection('referrals').where('referredUserId','==',id).get()]);
    return send(res,200,{ok:true,user:cleanDoc(u),withdrawals:w.docs.map(cleanDoc),transactions:tr.docs.map(cleanDoc),referrals:refs.docs.map(cleanDoc)});
  }
  const bal=url.pathname.match(/^\/api\/admin\/users\/([^/]+)\/balance$/);
  if(bal&&req.method==='POST'){
    const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const id=decodeURIComponent(bal[1]),x=await readBody(req),amount=Number(x.amount),type=String(x.type||'add'),reason=String(x.reason||'').slice(0,500),key=idempotency(req);
    if(!validInteger(amount)||!['add','deduct'].includes(type))return send(res,400,{ok:false,error:'Invalid balance adjustment'});
    const d=db(),adj=key?d.collection('transactions').doc('ADJKEY_'+crypto.createHash('sha256').update(t.id+key).digest('hex').slice(0,40)):d.collection('transactions').doc();
    if((await adj.get()).exists)return send(res,200,{ok:true,duplicate:true});
    let before=0,after=0;
    await d.runTransaction(async tx=>{const ur=userRef(id),s=await tx.get(ur);if(!s.exists)throw new Error('USER_NOT_FOUND');before=Number(s.data().balance||0);after=type==='add'?before+amount:before-amount;if(after<0)throw new Error('NEGATIVE_BALANCE');tx.update(ur,{balance:after,updatedAt:now()});tx.set(adj,{id:adj.id,telegramId:id,type:type==='add'?'balance_adjustment_add':'balance_adjustment_deduct',amount:type==='add'?amount:-amount,balanceAfter:after,reason,adminId:t.id,createdAt:now()});});
    await logAdmin(t.id,type==='add'?'ADD_BALANCE':'DEDUCT_BALANCE',id,before,after,reason);
    return send(res,200,{ok:true,balance:after});
  }
  const block=url.pathname.match(/^\/api\/admin\/users\/([^/]+)\/(block|unblock)$/);
  if(block&&req.method==='POST'){
    const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const id=decodeURIComponent(block[1]),action=block[2],x=await readBody(req),reason=String(x.reason||'').slice(0,500),ur=userRef(id);
    const old=await ur.get();if(!old.exists)return send(res,404,{ok:false,error:'User not found'});const before=old.data().status||'active',after=action==='block'?'blocked':'active';
    await ur.update({status:after,blockReason:after==='blocked'?reason:'',blockedBy:after==='blocked'?t.id:'',blockedAt:after==='blocked'?now():null,updatedAt:now()});
    await logAdmin(t.id,action==='block'?'BLOCK_USER':'UNBLOCK_USER',id,before,after,reason);
    return send(res,200,{ok:true,status:after});
  }

  if(url.pathname==='/api/admin/deposits'&&req.method==='GET'){
    const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const s=await db().collection('deposits').orderBy('createdAt','desc').limit(500).get();return send(res,200,{ok:true,deposits:s.docs.map(cleanDoc)});
  }
  const dep=url.pathname.match(/^\/api\/admin\/deposits\/([^/]+)\/(paid|rejected)$/);
  if(dep&&req.method==='POST'){
    const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const x=await readBody(req),id=decodeURIComponent(dep[1]),status=dep[2],reason=String(x.reason||'').slice(0,500),d=db(),dr=d.collection('deposits').doc(id);
    await d.runTransaction(async tx=>{const s=await tx.get(dr);if(!s.exists)throw new Error('NOT_FOUND');const v=s.data();if(v.status!=='pending')throw new Error('ALREADY_PROCESSED');if(status==='paid'){const ur=userRef(v.telegramId),u=await tx.get(ur);if(!u.exists)throw new Error('USER_NOT_FOUND');const before=Number(u.data().balance||0),after=before+Number(v.amount||0);tx.update(ur,{balance:after,totalDeposits:admin.firestore.FieldValue.increment(Number(v.amount||0)),updatedAt:now()});await addTx({telegramId:v.telegramId,type:'deposit',amount:Number(v.amount||0),balanceAfter:after,referenceId:id},tx)}tx.update(dr,{status,processedBy:t.id,processedAt:now(),rejectReason:status==='rejected'?reason:''})});
    await logAdmin(t.id,status==='paid'?'APPROVE_DEPOSIT':'REJECT_DEPOSIT','',null,status,reason);return send(res,200,{ok:true});
  }

  if(url.pathname==='/api/admin/withdrawals'&&req.method==='GET'){const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const s=await db().collection('withdrawals').orderBy('createdAt','desc').limit(500).get();return send(res,200,{ok:true,withdrawals:s.docs.map(cleanDoc)})}
  const wd=url.pathname.match(/^\/api\/admin\/withdrawals\/([^/]+)\/(approve|paid|rejected)$/);
  if(wd&&req.method==='POST'){
    const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const x=await readBody(req),id=decodeURIComponent(wd[1]),status=wd[2],reason=String(x.reason||''),paymentReference=String(x.paymentReference||'').slice(0,150),d=db(),wr=d.collection('withdrawals').doc(id);
    await d.runTransaction(async tx=>{const s=await tx.get(wr);if(!s.exists)throw new Error('NOT_FOUND');const v=s.data();if(!['pending','approved'].includes(v.status))throw new Error('ALREADY_PROCESSED');if(status==='rejected'){const ur=userRef(v.telegramId),u=await tx.get(ur);if(!u.exists)throw new Error('USER_NOT_FOUND');tx.update(ur,{balance:admin.firestore.FieldValue.increment(Number(v.amount||0)),pendingWithdrawals:admin.firestore.FieldValue.increment(-1),updatedAt:now()});await addTx({telegramId:v.telegramId,type:'refund',amount:Number(v.amount||0),referenceId:id,reason:'Withdrawal rejected'},tx);tx.update(wr,{status:'rejected',rejectReason:reason,processedBy:t.id,processedAt:now(),updatedAt:now()})}else if(status==='approve'){tx.update(wr,{status:'approved',approvedBy:t.id,approvedAt:now(),updatedAt:now()})}else{tx.update(wr,{status:'paid',paymentReference,paidBy:t.id,paidAt:now(),updatedAt:now()});const ur=userRef(v.telegramId);tx.update(ur,{pendingWithdrawals:admin.firestore.FieldValue.increment(-1),updatedAt:now()})}});
    await logAdmin(t.id,status==='approve'?'APPROVE_WITHDRAW':status==='paid'?'PAID_WITHDRAW':'REJECT_WITHDRAW','',null,status,reason);return send(res,200,{ok:true});
  }

  if(url.pathname==='/api/admin/referrals'&&req.method==='GET'){const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const s=await db().collection('referrals').orderBy('createdAt','desc').limit(500).get().catch(async()=>await db().collection('referrals').limit(500).get());return send(res,200,{ok:true,referrals:s.docs.map(cleanDoc)})}
  if(url.pathname==='/api/admin/settings'&&req.method==='GET'){const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});return send(res,200,{ok:true,settings:clean(await getSettings())})}
  if(url.pathname==='/api/admin/settings'&&req.method==='POST'){
    const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const x=await readBody(req),allowed=['coinName','signupBonusEnabled','signupBonus','minWithdraw','maxWithdraw','withdrawFeeType','withdrawFee','referralEnabled','referralBonus','withdrawalsEnabled','registrationEnabled','maintenanceMode','depositInstructions','paymentMethods'];
    const old=await getSettings(),next={};for(const k of allowed)if(x[k]!==undefined)next[k]=x[k];
    const numeric=['signupBonus','minWithdraw','maxWithdraw','withdrawFee','referralBonus'];for(const k of numeric)if(next[k]!==undefined){next[k]=Number(next[k]);if(!Number.isSafeInteger(next[k])||next[k]<0) return send(res,400,{ok:false,error:`Invalid ${k}`})}
    if(next.minWithdraw!==undefined&&next.maxWithdraw!==undefined&&next.maxWithdraw<next.minWithdraw)return send(res,400,{ok:false,error:'Maximum withdraw cannot be less than minimum'});
    if(next.minWithdraw===undefined)next.minWithdraw=Number(old.minWithdraw);if(next.maxWithdraw===undefined)next.maxWithdraw=Number(old.maxWithdraw);if(next.maxWithdraw<next.minWithdraw)return send(res,400,{ok:false,error:'Maximum withdraw cannot be less than minimum'});
    next.updatedAt=now();next.updatedBy=t.id;await settingsRef().set(next,{merge:true});await logAdmin(t.id,'CHANGE_SETTINGS','',old,next,String(x.reason||''));return send(res,200,{ok:true,settings:clean(await getSettings())});
  }
  if(url.pathname==='/api/admin/logs'&&req.method==='GET'){const t=await auth(req,true);if(t.error)return send(res,403,{ok:false,error:t.error});const s=await db().collection('adminLogs').orderBy('createdAt','desc').limit(500).get();return send(res,200,{ok:true,logs:s.docs.map(cleanDoc)})}
  return false;
}

async function telegram(method,body){
  if(!BOT_TOKEN)return null;
  const r=await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
  return r.json();
}
let updateOffset=0;
async function botLoop(){
  if(!BOT_TOKEN)return;
  try{
    const r=await telegram('getUpdates',{offset:updateOffset+1,timeout:20,allowed_updates:['message','callback_query']});
    if(!r?.ok)return;
    for(const u of r.result||[]){updateOffset=u.update_id;await handleBotUpdate(u)}
  }catch(e){console.error('Bot polling:',e.message)}
}
async function botReply(chatId,text,extra={}){return telegram('sendMessage',{chat_id:chatId,text,parse_mode:'HTML',...extra})}
async function handleBotUpdate(u){
  const m=u.message,c=u.callback_query;
  if(c){
    const id=String(c.from?.id||'');if(!ADMIN_IDS.has(id)){await telegram('answerCallbackQuery',{callback_query_id:c.id,text:'Access denied',show_alert:true});return}
    await telegram('answerCallbackQuery',{callback_query_id:c.id});
    const data=String(c.data||'');
    if(data==='dashboard'){const d=await db().collection('users').get();const s=await getSettings();await botReply(c.message.chat.id,`<b>BB Coin Dashboard</b>\nUsers: ${d.size}\nCoin: ${s.coinName}\nSignup bonus: ${s.signupBonus}\nMin withdraw: ${s.minWithdraw}`);return}
    if(data==='open'){await botReply(c.message.chat.id,'<b>Admin Panel</b>',{reply_markup:{inline_keyboard:[[APP_URL?{text:'Open Web Panel',web_app:{url:APP_URL+'/withdraw-ff/admin.html'}}:{text:'Set APP_URL first',callback_data:'dashboard'}]]}});return}
    if(data==='users'){const s=await db().collection('users').orderBy('createdAt','desc').limit(10).get();await botReply(c.message.chat.id,s.docs.map(x=>{const u=x.data();return `${u.telegramId} — ${u.username||u.firstName||''} — ${Number(u.balance||0).toLocaleString()}`}).join('\n')||'No users');return}
    if(data==='withdrawals'){const s=await db().collection('withdrawals').where('status','==','pending').limit(20).get();await botReply(c.message.chat.id,s.docs.map(x=>{const w=x.data();return `${w.id} — ${w.telegramId} — ${w.amount} — ${w.method}`}).join('\n')||'No pending withdrawals');return}
    if(data==='deposits'){const s=await db().collection('deposits').where('status','==','pending').limit(20).get();await botReply(c.message.chat.id,s.docs.map(x=>{const d=x.data();return `${d.id} — ${d.telegramId} — ${d.amount} — ${d.reference}`}).join('\n')||'No pending deposits');return}
    if(data==='settings'){const s=await getSettings();await botReply(c.message.chat.id,`Coin: ${s.coinName}\nSignup bonus: ${s.signupBonus} (${s.signupBonusEnabled?'ON':'OFF'})\nMin: ${s.minWithdraw}\nMax: ${s.maxWithdraw}\nFee: ${s.withdrawFee}${s.withdrawFeeType==='percent'?'%':''}\nReferral: ${s.referralBonus}`);return}
    return;
  }
  if(!m)return;
  const id=String(m.from?.id||''),chat=m.chat.id,text=String(m.text||'').trim();
  if(text==='/start'){await botReply(chat,ADMIN_IDS.has(id)?'<b>Admin Bot</b>\nUse /admin for the control menu.':'Welcome to BB Coin Mini App. Use the bot menu to open the app.');return}
  if(text==='/admin'){
    if(!ADMIN_IDS.has(id))return botReply(chat,'Access Denied');
    return botReply(chat,'<b>Admin Menu</b>',{reply_markup:{inline_keyboard:[
      [{text:'📊 Dashboard',callback_data:'dashboard'},{text:'👥 Users',callback_data:'users'}],
      [{text:'📥 Deposits',callback_data:'deposits'},{text:'📤 Withdrawals',callback_data:'withdrawals'}],
      [{text:'⚙️ Settings',callback_data:'settings'}],
      [APP_URL?{text:'🖥️ Open Admin Panel',web_app:{url:APP_URL+'/withdraw-ff/admin.html'}}:{text:'Set APP_URL',callback_data:'dashboard'}]
    ]}});
  }
  if(!ADMIN_IDS.has(id))return;
  let mm=text.match(/^\/(setbonus|setmin|setmax|setrefbonus)\s+(\d+)$/i);
  if(mm){const field={setbonus:'signupBonus',setmin:'minWithdraw',setmax:'maxWithdraw',setrefbonus:'referralBonus'}[mm[1].toLowerCase()],value=Number(mm[2]),s=await getSettings();if(field==='maxWithdraw'&&value<s.minWithdraw)return botReply(chat,'Maximum withdraw cannot be below minimum.');const old=s[field];await settingsRef().set({[field]:value,updatedAt:now(),updatedBy:id},{merge:true});await logAdmin(id,'CHANGE_'+field.toUpperCase(),'',''+old,''+value,'Telegram bot');return botReply(chat,`Updated ${field}: ${value}`)}
  mm=text.match(/^\/(block|unblock)\s+(\d+)$/i);if(mm){const uid=mm[2],a=mm[1].toLowerCase(),r=userRef(uid),s=await r.get();if(!s.exists)return botReply(chat,'User not found');await r.update({status:a==='block'?'blocked':'active',blockReason:a==='block'?'Blocked by admin bot':'',blockedBy:a==='block'?id:'',blockedAt:a==='block'?now():null,updatedAt:now()});await logAdmin(id,a==='block'?'BLOCK_USER':'UNBLOCK_USER',uid,s.data().status||'active',a==='block'?'blocked':'active','Telegram bot');return botReply(chat,'Done')}
  mm=text.match(/^\/(add|deduct)\s+(\d+)\s+(\d+)$/i);if(mm){const uid=mm[2],amount=Number(mm[3]),type=mm[1].toLowerCase()==='add'?'add':'deduct';const r=userRef(uid);let after=0;await db().runTransaction(async tx=>{const s=await tx.get(r);if(!s.exists)throw new Error('USER_NOT_FOUND');const b=Number(s.data().balance||0);after=type==='add'?b+amount:b-amount;if(after<0)throw new Error('NEGATIVE_BALANCE');tx.update(r,{balance:after,updatedAt:now()});await addTx({telegramId:uid,type:type==='add'?'balance_adjustment_add':'balance_adjustment_deduct',amount:type==='add'?amount:-amount,balanceAfter:after,adminId:id,reason:'Telegram bot'},tx)});await logAdmin(id,type==='add'?'ADD_BALANCE':'DEDUCT_BALANCE',uid,null,after,'Telegram bot');return botReply(chat,`Balance: ${after}`)}
}
if(BOT_TOKEN)botLoop(),setInterval(botLoop,1000);

const root=path.resolve(__dirname);
async function route(req,res){
  try{
    const url=new URL(req.url,'http://localhost');
    if(url.pathname.startsWith('/api/')){const handled=await api(req,res,url);if(handled!==false)return;}    
    let file=decodeURIComponent(url.pathname);if(file==='/')file='/index.html';
    if(file==='/.env'||file.startsWith('/.private/')||file==='/package-lock.json')return send(res,404,{ok:false,error:'Not found'});
    const full=path.resolve(root,'.'+file);if(!full.startsWith(root)||!fs.existsSync(full)||fs.statSync(full).isDirectory())return send(res,404,{ok:false,error:'Not found'});
    const ext=path.extname(full),types={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'};
    res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':ext===' .html'?'no-store':'public,max-age=3600'});fs.createReadStream(full).pipe(res);
  }catch(e){console.error(e);const map={REGISTRATION_DISABLED:'Registration is disabled',BLOCKED:'Account is blocked',INSUFFICIENT_BALANCE:'Insufficient balance',NEGATIVE_BALANCE:'Balance cannot be negative',USER_NOT_FOUND:'User not found',ALREADY_PROCESSED:'Already processed',BODY_TOO_LARGE:'Request too large',INVALID_JSON:'Invalid JSON'};send(res,400,{ok:false,error:map[e.message]||'Server error'})}
}
http.createServer(route).listen(PORT,()=>console.log(`BB Coin server listening on ${PORT}`));
