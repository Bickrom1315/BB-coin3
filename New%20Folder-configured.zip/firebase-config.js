window.MAGIA_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBaM6fVIaabbyjPwWWTcKhpyeOWiarzrbs",
  authDomain: "fire-aedd7.firebaseapp.com",
  projectId: "fire-aedd7",
  storageBucket: "fire-aedd7.firebasestorage.app",
  messagingSenderId: "851709655643",
  appId: "1:851709655643:web:a675c00f81363769261d7e",
  measurementId: "G-1BD25G7BGC"
};
