
const STORAGE_KEY="bbcoin_ui_cache_v2";
const NFTS=[
{name:"Mystic Sage",price:100,img:"assets/nft/nft-01.png"},{name:"Fire Mage",price:250,img:"assets/nft/nft-02.png"},
{name:"Moon Witch",price:500,img:"assets/nft/nft-03.png"},{name:"Forest Wizard",price:1000,img:"assets/nft/nft-04.png"},
{name:"Crystal Mage",price:2500,img:"assets/nft/nft-05.png"},{name:"Arcane Knight",price:5000,img:"assets/nft/nft-06.png"},
{name:"Star Sorcerer",price:7500,img:"assets/nft/nft-07.png"},{name:"Shadow Mage",price:10000,img:"assets/nft/nft-08.png"},
{name:"Royal Wizard",price:15000,img:"assets/nft/nft-09.png"},{name:"Dragon Mage",price:25000,img:"assets/nft/nft-10.png"},
{name:"Grand Magician",price:50000,img:"assets/nft/nft-11.png"},{name:"Eternal Mage",price:100000,img:"assets/nft/nft-12.png"}];
let currentUser=null,settings=null;
const tg=()=>window.Telegram?.WebApp;
function initData(){return tg()?.initData||''}
async function api(path,opts={}){const headers={...(opts.headers||{}),'Content-Type':'application/json','X-Telegram-Init-Data':initData()};if(!opts.method||opts.method==='GET'){} const r=await fetch(path,{...opts,headers});const x=await r.json().catch(()=>({}));if(!r.ok)throw Error(x.error||'Request failed');return x}
function money(v){return Number(v||0).toLocaleString()}
function render(){if(!currentUser)return;document.getElementById('balance').textContent=money(currentUser.balance);document.querySelectorAll('.coin-name').forEach(e=>e.textContent=settings?.coinName||window.COIN_NAME||'BB Coin');document.getElementById('refCount').textContent=currentUser.referralCount||0;document.getElementById('refIncome').textContent=money(currentUser.referralEarnings||0);document.getElementById('magicBalance').textContent='2500';document.getElementById('dailyIncome').textContent='0';document.getElementById('collectionDaily').textContent='0';document.getElementById('availableIncome').textContent='0';}
function renderNFTs(){nftGrid.innerHTML=NFTS.map((n,i)=>`<article class="nft-card"><img src="${n.img}" alt="${n.name}"><h3>${n.name}</h3><p>Price: 🪙 ${money(n.price)}</p><p>Daily income: 🪙 0</p><p>Owned: 0</p><button disabled>Buy</button></article>`).join('')}
function openPage(id){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));document.getElementById(id)?.classList.add('active');document.querySelectorAll('nav button').forEach(x=>x.classList.toggle('active',x.dataset.page===id));if(id==='withdraw')document.getElementById('withdrawFrame')?.contentWindow?.postMessage({type:'refresh'},'*')}
async function submitDeposit(){const amount=Number(depositAmount.value),reference=String(depositRef.value||'').trim(),method=String(document.getElementById('depositMethod')?.value||'Manual');if(!Number.isSafeInteger(amount)||amount<=0)return alert('Enter a valid whole amount.');if(!reference)return alert('Enter transaction/reference ID.');try{const r=await api('/api/deposit',{method:'POST',headers:{'X-Idempotency-Key':crypto.randomUUID?.()||String(Date.now())},body:JSON.stringify({amount,reference,method})});alert('Deposit submitted. Waiting for admin verification.');depositAmount.value='';depositRef.value='';}catch(e){alert(e.message)}}
function copyReferral(){const el=document.getElementById('refLink');navigator.clipboard?.writeText(el.value);alert('Copied')}
function setupTelegram(){if(tg()){tg().ready();tg().expand();const u=tg().initDataUnsafe?.user;if(u){userId.textContent=u.id;userName.textContent=[u.first_name,u.last_name].filter(Boolean).join(' ')||'Telegram User';username.textContent=u.username?'@'+u.username:'Not set';if(u.photo_url){telegramPhoto.src=u.photo_url;profilePhoto.src=u.photo_url}}}}
async function load(){setupTelegram();try{if(!initData())throw Error('Open this Mini App from Telegram.');const r=await api('/api/user/sync',{method:'POST',body:'{}'});currentUser=r.user;settings=r.settings;render();renderNFTs();refLink.value=`https://t.me/${window.BOT_USERNAME||'YourBot'}?start=${currentUser.telegramId}`;if(r.user.isNew)alert(`Welcome! ${money(r.user.signupBonus)} ${settings.coinName} signup bonus added.`)}catch(e){console.error(e);alert(e.message)}}
renderNFTs();load();
