# BB Coin Telegram Mini App + Admin System

This revision converts the starter into a server-authoritative BB Coin system. The existing visual assets and Mini App pages are preserved as much as practical.

## Architecture
- Telegram Mini App: `index.html`, `app.js`, `withdraw-ff/*`
- Backend + Telegram bot polling: `server.js`
- Firestore collections: `users`, `settings/global`, `deposits`, `withdrawals`, `transactions`, `referrals`, `adminLogs`, `adminSessions`
- Firebase Admin SDK exists only on the server.
- Browser localStorage is not a balance source of truth. It is used only for payout-address UI caching in this starter.

## Important production setup
1. Create a Firestore database in the Firebase project.
2. A private Firebase service-account JSON is included under `.private/` for this prepared package; keep that directory private.
3. The prepared package already has `.env` with the supplied Telegram bot token and admin ID.
4. Set:
   - `BOT_TOKEN`
   - `ADMIN_TELEGRAM_IDS` as comma-separated numeric Telegram IDs
   - `APP_URL` to the HTTPS Mini App origin
   - `FIREBASE_SERVICE_ACCOUNT_JSON` (or `GOOGLE_APPLICATION_CREDENTIALS`) only if you do not use the included `.private/` key
5. `npm install`
6. `npm start`
7. Configure the bot's Menu Button / Mini App URL in BotFather.
8. Open the Mini App from Telegram. Direct browser access is not an authenticated user session.

## Default rules
- Currency: BB Coin
- Signup bonus: 100000 BB Coin
- Minimum withdrawal: 10000 BB Coin
- Maximum withdrawal: 1,000,000,000 BB Coin (admin can change)
- Withdrawal fee: 0 fixed by default
- Referral bonus: 0 by default
- Registration and withdrawals are enabled by default.

## Bot admin commands
`/admin` — admin-only inline menu.
`/setbonus 5000`
`/setmin 10000`
`/setmax 1000000`
`/setrefbonus 100`
`/block 123456789`
`/unblock 123456789`
`/add 123456789 5000`
`/deduct 123456789 5000`

Callback handlers re-check the Telegram sender ID server-side.

## Firestore security
`firestore.rules` denies direct client reads/writes. All financial operations use the Admin SDK on the backend.

## Data integrity
- Signup bonus is created inside a Firestore transaction.
- Withdrawal reserves/deducts balance atomically.
- Deposit approval credits balance atomically and only once.
- Withdrawal rejection refunds once.
- Admin balance adjustments are atomic and can use an idempotency key.
- Financial amounts are validated as safe positive integers.
- Blocked accounts are rejected server-side.
- Admin actions create immutable-style audit records (normal admin APIs do not expose deletion/edit operations).

## What remains operator-controlled
Crypto payouts are not automatically broadcast to TON/BSC. An admin must verify the payment and, after the external payout is actually sent, mark a withdrawal paid and store its payment reference.

Payout addresses in this revision remain in the browser UI cache. For a high-value production deployment, move them to a Firestore user subdocument and enforce a server-side 24-hour address-change lock before accepting withdrawals.

## Migration from the old starter
The old project stored balances in localStorage and had an incomplete Firestore backend. Do not treat those browser balances as authoritative. Before production, import any legitimate existing balances through a controlled one-time migration script into `users.balance`, with a migration transaction/audit entry. Never run two balance databases in parallel.

## Verification checklist
Test with real Telegram accounts:
- Admin `/admin` vs normal-user access denied
- Signed `initData`
- New-user signup bonus exactly once
- Settings apply to new transactions
- Block/unblock enforcement
- Deposit pending/paid/rejected
- Withdrawal pending/approve/paid/rejected/refund
- Concurrent withdrawals cannot overdraw
- Duplicate idempotency keys do not duplicate credits/debits
- Restart does not lose Firestore data
- Mobile Mini App UI
