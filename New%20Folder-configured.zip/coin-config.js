window.COIN_NAME = "BB Coin";
