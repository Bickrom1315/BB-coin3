MAGIA TELEGRAM MINI APP

Developer-controlled images:
assets/background.jpg
assets/nft/nft-01.png ... nft-12.png

Replace these files with your own images using the same filenames.
There are NO user image upload controls.

Telegram profile photo is read from Telegram Web App user.photo_url.

A new local account starts with 1000 balance.
NFT daily income is calculated as 10% of purchase price per 24 hours
and accrues continuously in this frontend version.

IMPORTANT:
This is a frontend/local simulation. Deposit and withdrawal are not real
payment processing. For production, Telegram initData, balances, NFT buys,
deposits, withdrawals and referrals must be validated/stored server-side
by Telegram user ID.

Currency name is configured once in coin-config.js (BB Coin by default). The main app and withdraw iframe use the same localStorage account balance key.
